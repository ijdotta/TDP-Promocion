package gui.commands;

public interface Command {
	
	/**
	 * Ejecuta el comando.
	 */
	public void execute();

}
